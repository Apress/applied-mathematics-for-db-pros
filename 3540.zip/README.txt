Contents of this zipfile.
-------------------------

./Chapter11/am4dp_create.sql
  ==> Holds the create-table statements and all declaratively stateable data integrity constraints for the example database design.
./Chapter11/am4dp_database_state.sql
  ==> Holds insert statements to populate the tables with example data that satisfies all data integrity constraints.
./Chapter11/am4dp_em6_TE_queries.txt
  ==> Lists the Transition Effect queries for all multi-tuple constraints according to execution model EM6.
./Chapter11/am4dp_em6_CV_queries.txt
  ==> Lists the Constraint Validation queries for all multi-tuple constraints according to execution model EM6.

